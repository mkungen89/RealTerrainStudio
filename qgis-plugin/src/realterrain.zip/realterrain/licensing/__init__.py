"""Licensing module for RealTerrain Studio."""
