"""
License Manager

Handles license validation, storage, and communication with Supabase backend.
"""

import os
import json
import base64
from datetime import datetime
from typing import Optional, Dict, Tuple
from pathlib import Path

from qgis.PyQt.QtCore import QSettings

from .hardware_fingerprint import get_hardware_fingerprint


class LicenseStatus:
    """License status constants."""
    FREE = "free"
    PRO = "pro"
    EXPIRED = "expired"
    INVALID = "invalid"
    NOT_ACTIVATED = "not_activated"


class LicenseManager:
    """Manages license validation and storage."""

    def __init__(self):
        """Initialize the license manager."""
        self.settings = QSettings("RealTerrainStudio", "QGIS")
        self.hardware_id = get_hardware_fingerprint()

        # License limits (Free tier)
        self.FREE_TIER_LIMITS = {
            "max_area_km2": 10,
            "monthly_exports": 10,
            "max_resolution_m": 30,
        }

    def get_license_status(self) -> str:
        """
        Get current license status.

        Returns:
            str: One of LicenseStatus constants
        """
        # Check if license key exists
        license_key = self.settings.value("license/key", "")

        if not license_key:
            # No license key - using free version
            return LicenseStatus.FREE

        # Validate stored license
        is_valid, status = self._validate_stored_license()

        if not is_valid:
            return status

        return LicenseStatus.PRO

    def activate_license(self, license_key: str) -> Tuple[bool, str]:
        """
        Activate a license key.

        Args:
            license_key: The license key to activate

        Returns:
            Tuple[bool, str]: (success, message)
        """
        if not license_key or len(license_key.strip()) == 0:
            return False, "License key cannot be empty"

        # Format and validate key format
        license_key = license_key.strip().upper()

        if not self._validate_key_format(license_key):
            return False, "Invalid license key format"

        # TODO: Validate against Supabase backend
        # For now, we'll do a mock validation
        success, message = self._validate_with_backend(license_key)

        if success:
            # Store license information
            self._store_license(license_key)
            return True, "License activated successfully!"

        return False, message

    def deactivate_license(self) -> bool:
        """
        Deactivate the current license.

        Returns:
            bool: True if successful
        """
        self.settings.remove("license/key")
        self.settings.remove("license/activated_date")
        self.settings.remove("license/user_email")
        self.settings.sync()
        return True

    def get_license_info(self) -> Dict:
        """
        Get detailed license information.

        Returns:
            dict: License information including status, limits, etc.
        """
        status = self.get_license_status()

        info = {
            "status": status,
            "hardware_id": self.hardware_id,
        }

        if status == LicenseStatus.FREE:
            info["tier"] = "Free"
            info["limits"] = self.FREE_TIER_LIMITS
            info["message"] = "Using free version with limited features"

        elif status == LicenseStatus.PRO:
            license_key = self.settings.value("license/key", "")
            activated_date = self.settings.value("license/activated_date", "")
            user_email = self.settings.value("license/user_email", "")

            info["tier"] = "Pro"
            info["license_key"] = self._mask_license_key(license_key)
            info["activated_date"] = activated_date
            info["user_email"] = user_email
            info["limits"] = {
                "max_area_km2": "Unlimited",
                "monthly_exports": "Unlimited",
                "max_resolution_m": "1m (highest available)",
            }
            info["message"] = "Pro license active"

        elif status == LicenseStatus.EXPIRED:
            info["tier"] = "Expired"
            info["message"] = "Your license has expired. Please renew."

        elif status == LicenseStatus.INVALID:
            info["tier"] = "Invalid"
            info["message"] = "License validation failed. Please contact support."

        return info

    def check_export_allowed(self, area_km2: float) -> Tuple[bool, str]:
        """
        Check if an export is allowed based on license.

        Args:
            area_km2: Area size in square kilometers

        Returns:
            Tuple[bool, str]: (allowed, message)
        """
        status = self.get_license_status()

        if status == LicenseStatus.PRO:
            return True, "Export allowed"

        if status == LicenseStatus.FREE:
            if area_km2 > self.FREE_TIER_LIMITS["max_area_km2"]:
                return False, f"Free tier limited to {self.FREE_TIER_LIMITS['max_area_km2']} km². Upgrade to Pro for unlimited exports."

            # TODO: Check monthly export count
            # For now, allow the export
            return True, "Export allowed (Free tier)"

        if status == LicenseStatus.EXPIRED:
            return False, "License expired. Please renew your license."

        if status == LicenseStatus.INVALID:
            return False, "Invalid license. Please contact support."

        return False, "License validation failed"

    def _validate_key_format(self, key: str) -> bool:
        """
        Validate the format of a license key.

        Expected format: XXXX-XXXX-XXXX-XXXX (16 alphanumeric characters)

        Args:
            key: License key to validate

        Returns:
            bool: True if format is valid
        """
        # Remove dashes
        key_clean = key.replace("-", "")

        # Should be 16 characters
        if len(key_clean) != 16:
            return False

        # Should be alphanumeric
        if not key_clean.isalnum():
            return False

        return True

    def _validate_with_backend(self, license_key: str) -> Tuple[bool, str]:
        """
        Validate license key with Supabase backend.

        Args:
            license_key: License key to validate

        Returns:
            Tuple[bool, str]: (success, message)
        """
        # TODO: Implement actual Supabase validation
        # For now, use mock validation for testing

        # Mock: Accept any key that starts with "PRO-"
        if license_key.startswith("PRO-"):
            return True, "License validated successfully"

        # Mock: Accept specific test keys
        test_keys = [
            "TEST-1234-5678-ABCD",
            "DEMO-ABCD-1234-EFGH",
        ]

        if license_key in test_keys:
            return True, "License validated successfully"

        return False, "Invalid license key. Please check and try again."

    def _validate_stored_license(self) -> Tuple[bool, str]:
        """
        Validate the stored license.

        Returns:
            Tuple[bool, str]: (is_valid, status)
        """
        license_key = self.settings.value("license/key", "")

        if not license_key:
            return False, LicenseStatus.NOT_ACTIVATED

        # Validate format
        if not self._validate_key_format(license_key):
            return False, LicenseStatus.INVALID

        # TODO: Periodically re-validate with backend
        # For now, trust stored license
        return True, LicenseStatus.PRO

    def _store_license(self, license_key: str):
        """
        Store license information locally.

        Args:
            license_key: License key to store
        """
        self.settings.setValue("license/key", license_key)
        self.settings.setValue("license/activated_date", datetime.now().isoformat())
        self.settings.setValue("license/hardware_id", self.hardware_id)

        # TODO: Store user email from backend response
        self.settings.setValue("license/user_email", "user@example.com")

        self.settings.sync()

    def _mask_license_key(self, key: str) -> str:
        """
        Mask a license key for display.

        Args:
            key: License key to mask

        Returns:
            str: Masked key (e.g., XXXX-XXXX-****-****)
        """
        if not key:
            return ""

        # Remove dashes
        key_clean = key.replace("-", "")

        if len(key_clean) < 8:
            return "****-****-****-****"

        # Show first 8 chars, mask the rest
        visible = key_clean[:8]
        masked = visible[:4] + "-" + visible[4:8] + "-****-****"

        return masked

    def is_first_run(self) -> bool:
        """
        Check if this is the first run of the plugin.

        Returns:
            bool: True if first run
        """
        first_run = self.settings.value("app/first_run", True, type=bool)
        return first_run

    def mark_first_run_complete(self):
        """Mark that the first run has been completed."""
        self.settings.setValue("app/first_run", False)
        self.settings.sync()
